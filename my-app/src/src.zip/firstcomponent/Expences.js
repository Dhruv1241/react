import React, { useState } from 'react'
import Expenceitem from './expenceitem';
import ExpenceFilters from './ExpenceFilters';

export default function Expences(props) {

    const [filterdyear, setfilterdyear] = useState('2020')

    const filterchangehandler = selectedyear => {
        setfilterdyear(selectedyear)
    }
    return (
        <div>
            <ExpenceFilters selected={filterdyear} onchangefilter={filterchangehandler} />
            {props.item.map(exp => (
                <Expenceitem
                    title={exp.title}
                    amount={exp.amount}
                    date={exp.date} 
                    key={exp.id}/>
            ))}

            
        </div>
    )
}
